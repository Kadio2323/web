import React, { useState, useEffect } from 'react';
import axios from 'axios';
import {
  User,
  Lock,
  Eye,
  EyeOff,
  ArrowRight,
  Globe,
  Loader2,
  ChevronDown,
  Check,
} from 'lucide-react';
import './Login.css';
import { API_BASE_URL } from '../../config';
import { BRAND, DEVELOPERS, SOCIAL, tagline } from '../../brand/brand';
import { HeximMark, HeximLockup } from '../Brand/HeximLogo';
import { useLanguage, LANGUAGES } from '../../i18n/LanguageContext';

interface UserData {
  id: number;
  username: string;
  role: string;
  gateKey: string;
}

interface LoginProps {
  onLoginSuccess: (user: UserData, token: string) => void;
}

const FEATURES = [
  { title: 'Canlı telemetri', desc: 'Cihaz durumu, sistem bilgisi ve oturum akışı gerçek zamanlı.' },
  { title: 'Gate key koruması', desc: 'Her istemci kendi anahtarıyla bağlanır, yetkisiz erişim yok.' },
  { title: 'Anlık derleme', desc: 'Sunucuya bağlı istemciyi panelden saniyeler içinde üret.' },
];

const DiscordGlyph = ({ size = 16 }: { size?: number }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
    <path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0 12.64 12.64 0 0 0-.617-1.25.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 0 0 .031.057 19.9 19.9 0 0 0 5.993 3.03.078.078 0 0 0 .084-.028 14.09 14.09 0 0 0 1.226-1.994.076.076 0 0 0-.041-.106 13.107 13.107 0 0 1-1.872-.892.077.077 0 0 1-.008-.128 10.2 10.2 0 0 0 .372-.292.074.074 0 0 1 .077-.01c3.928 1.793 8.18 1.793 12.061 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 1-.006.127 12.299 12.299 0 0 1-1.873.892.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028 19.839 19.839 0 0 0 6.002-3.03.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.028ZM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.956-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.956 2.418-2.157 2.418Zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.955-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.946 2.418-2.157 2.418Z" />
  </svg>
);

export const Login: React.FC<LoginProps> = ({ onLoginSuccess }) => {
  const { language, setLanguage, t } = useLanguage();
  const [langMenuOpen, setLangMenuOpen] = useState(false);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const currentLangObj = LANGUAGES.find((l) => l.code === language) || LANGUAGES[0];

  useEffect(() => {
    const closeDropdown = () => setLangMenuOpen(false);
    if (langMenuOpen) window.addEventListener('click', closeDropdown);
    return () => window.removeEventListener('click', closeDropdown);
  }, [langMenuOpen]);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      const response = await axios.post(`${API_BASE_URL}/api/auth/login`, { username, password });
      if (response.data.success) {
        onLoginSuccess(response.data.user, response.data.token);
      }
    } catch (err: any) {
      if (err.response?.data?.message) setError(err.response.data.message);
      else setError(t('login.error_server'));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="hx-login">
      <div className="hx-atmosphere" aria-hidden="true" />

      {/* language selector */}
      <div className="hx-lang" onClick={(e) => e.stopPropagation()}>
        <button
          type="button"
          className={`hx-lang-btn ${langMenuOpen ? 'is-open' : ''}`}
          onClick={() => setLangMenuOpen((prev) => !prev)}
          aria-haspopup="listbox"
          aria-expanded={langMenuOpen}
        >
          <Globe size={13} />
          <img src={currentLangObj.flag} alt="" className="hx-lang-flag" />
          <span>{currentLangObj.name}</span>
          <ChevronDown size={12} className={`hx-lang-chevron ${langMenuOpen ? 'is-open' : ''}`} />
        </button>

        {langMenuOpen && (
          <div className="hx-lang-menu" role="listbox">
            {LANGUAGES.map((l) => (
              <button
                key={l.code}
                type="button"
                role="option"
                aria-selected={language === l.code}
                className={`hx-lang-item ${language === l.code ? 'is-active' : ''}`}
                onClick={() => {
                  setLanguage(l.code);
                  setLangMenuOpen(false);
                }}
              >
                <img src={l.flag} alt="" className="hx-lang-flag" />
                <span>{l.name}</span>
                {language === l.code && <Check size={13} className="hx-lang-check" />}
              </button>
            ))}
          </div>
        )}
      </div>

      <div className="hx-login-grid">
        {/* brand side */}
        <section className="hx-login-brand">
          <header className="hx-brand-head">
            <HeximLockup size={38} />
            <span className="hx-brand-version">{BRAND.version}</span>
          </header>

          <div className="hx-brand-body">
            <span className="hx-eyebrow">
              <span className="hx-dot" /> panel çevrimiçi
            </span>
            <h1 className="hx-brand-title">
              Kontrol <em>sende.</em>
            </h1>
            <p className="hx-brand-lede">{tagline(language)}</p>

            <ol className="hx-feature-list">
              {FEATURES.map((f, i) => (
                <li key={f.title} className="hx-feature">
                  <span className="hx-feature-index">{String(i + 1).padStart(2, '0')}</span>
                  <span className="hx-feature-copy">
                    <strong>{f.title}</strong>
                    <em>{f.desc}</em>
                  </span>
                </li>
              ))}
            </ol>
          </div>

          <footer className="hx-developers">
            <div className="hx-dev-head">
              <span>Developers</span>
              <span className="hx-dev-line" />
            </div>
            <div className="hx-dev-grid">
              {DEVELOPERS.map((dev) => (
                <div className="hx-dev-card" key={dev.name}>
                  <span className="hx-dev-avatar">{dev.initials}</span>
                  <span className="hx-dev-meta">
                    <strong>{dev.name}</strong>
                    <em>{dev.role}</em>
                  </span>
                </div>
              ))}
            </div>
            <a className="hx-dev-discord" href={SOCIAL.discord} target="_blank" rel="noopener noreferrer">
              <DiscordGlyph size={13} />
              <span>discord.gg/hD99cGZWY5</span>
            </a>
          </footer>
        </section>

        {/* auth side */}
        <section className="hx-login-panel">
          <div className="hx-auth-card">
            <div className="hx-auth-top">
              <HeximMark size={26} />
              <span className="hx-auth-kicker">auth / 01</span>
            </div>

            <header className="hx-auth-head">
              <h2>Oturum aç</h2>
              <p>Panel erişimi için kimlik bilgilerini gir.</p>
            </header>

            {error && (
              <div className="hx-error" role="alert">
                <span className="hx-error-dot" />
                {error}
              </div>
            )}

            <form onSubmit={handleLogin} className="hx-form">
              <label className="hx-field" htmlFor="username">
                <span className="hx-field-label">{t('login.username')}</span>
                <span className="hx-input-wrap">
                  <User size={15} className="hx-input-icon" />
                  <input
                    id="username"
                    type="text"
                    className="hx-input"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    placeholder="operator"
                    autoComplete="off"
                    spellCheck={false}
                    required
                  />
                </span>
              </label>

              <label className="hx-field" htmlFor="password">
                <span className="hx-field-label">{t('login.password')}</span>
                <span className="hx-input-wrap">
                  <Lock size={15} className="hx-input-icon" />
                  <input
                    id="password"
                    type={showPassword ? 'text' : 'password'}
                    className="hx-input"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••••"
                    required
                  />
                  <button
                    type="button"
                    className="hx-input-action"
                    onClick={() => setShowPassword((prev) => !prev)}
                    aria-label={showPassword ? 'Şifreyi gizle' : 'Şifreyi göster'}
                    tabIndex={-1}
                  >
                    {showPassword ? <EyeOff size={15} /> : <Eye size={15} />}
                  </button>
                </span>
              </label>

              <button type="submit" className="hx-submit" disabled={loading}>
                {loading ? (
                  <>
                    <Loader2 size={15} className="hx-spin" />
                    {t('login.logging_in')}
                  </>
                ) : (
                  <>
                    {t('login.submit')}
                    <ArrowRight size={15} />
                  </>
                )}
              </button>
            </form>

            <footer className="hx-auth-foot">
              <span className="hx-auth-chip">
                <span className="hx-dot" /> secure channel
              </span>
              <span className="hx-auth-meta">{BRAND.version}</span>
            </footer>
          </div>

          <p className="hx-auth-credit">
            Developed by <strong>{DEVELOPERS.map((d) => d.name).join(' & ')}</strong>
          </p>
        </section>
      </div>
    </div>
  );
};
