import React from 'react';
import { BRAND } from '../../brand/brand';
import './HeximLogo.css';

interface MarkProps {
  size?: number;
  className?: string;
  glow?: boolean;
  title?: string;
}

/**
 * Hexim mark — a hexagon shell around a cut 'H'.
 * Gradient is defined per-instance with a unique id so multiple marks
 * on the same page never fight over defs.
 */
export const HeximMark: React.FC<MarkProps> = ({
  size = 40,
  className = '',
  glow = false,
  title = 'Hexim',
}) => {
  const rawId = React.useId();
  const uid = rawId.replace(/[^a-zA-Z0-9]/g, '');
  const gradientId = `hxGrad${uid}`;
  const filterId = `hxGlow${uid}`;

  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 64 64"
      fill="none"
      className={`hexim-mark ${className}`}
      role="img"
      aria-label={title}
    >
      <defs>
        <linearGradient id={gradientId} x1="8" y1="4" x2="56" y2="60" gradientUnits="userSpaceOnUse">
          <stop stopColor="#e6cd9a" />
          <stop offset="0.5" stopColor="#c9a86a" />
          <stop offset="1" stopColor="#93764a" />
        </linearGradient>
        <filter id={filterId} x="-60%" y="-60%" width="220%" height="220%">
          <feGaussianBlur stdDeviation="2.4" result="blur" />
          <feMerge>
            <feMergeNode in="blur" />
            <feMergeNode in="SourceGraphic" />
          </feMerge>
        </filter>
      </defs>

      <path
        d="M32 3.4 55.9 17.1v29.8L32 60.6 8.1 46.9V17.1L32 3.4Z"
        stroke={`url(#${gradientId})`}
        strokeWidth="2.6"
        strokeLinejoin="round"
        opacity="0.95"
        filter={glow ? `url(#${filterId})` : undefined}
      />
      <path
        d="M32 9.8 50.2 20.2v23.6L32 54.2 13.8 43.8V20.2L32 9.8Z"
        stroke={`url(#${gradientId})`}
        strokeWidth="1"
        strokeLinejoin="round"
        opacity="0.3"
      />
      <path
        d="M24.2 21.5v21M39.8 21.5v21M24.2 32h15.6"
        stroke={`url(#${gradientId})`}
        strokeWidth="3.6"
        strokeLinecap="round"
      />
      <circle cx="32" cy="32" r="1.9" fill="#f0dcb2" opacity="0.95" />
    </svg>
  );
};

interface LockupProps {
  size?: number;
  className?: string;
  compact?: boolean;
  glow?: boolean;
}

/** Mark + wordmark, used in the sidebar, login hero and page chrome. */
export const HeximLockup: React.FC<LockupProps> = ({
  size = 38,
  className = '',
  compact = false,
  glow = false,
}) => (
  <div className={`hexim-lockup ${compact ? 'is-compact' : ''} ${className}`}>
    <span className="hexim-lockup-mark">
      <HeximMark size={size} glow={glow} />
    </span>
    {!compact && (
      <span className="hexim-lockup-text">
        <span className="hexim-wordmark">
          {BRAND.wordmark}
          <span className="hexim-wordmark-dot">.</span>
        </span>
        <span className="hexim-wordmark-sub">{BRAND.wordmarkTail}</span>
      </span>
    )}
  </div>
);

export default HeximMark;
