import React, { useState, useEffect } from 'react';
import axios from 'axios';
import {
  Bot,
  Settings as SettingsIcon,
  LogOut,
  Hammer,
  Menu,
  X,
  ChevronDown,
  Check,
  Globe,
  Power,
  Clock3,
  Sparkles,
} from 'lucide-react';
import { socket } from '../../socket';
import { API_BASE_URL } from '../../config';
import './Dashboard.css';

import { Bots } from '../Bots/Bots';
import { Discord } from '../Discord/Discord';
import { Settings } from '../Settings/Settings';
import { Builder } from '../Builder/Builder';

import { HeximLockup } from '../Brand/HeximLogo';
import { BRAND, DEVELOPERS, SOCIAL, pageSubtitle, type PageKey } from '../../brand/brand';
import { useLanguage, LANGUAGES } from '../../i18n/LanguageContext';

const DiscordIcon = ({ size = 18 }: { size?: number }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
    <path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0 12.64 12.64 0 0 0-.617-1.25.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 0 0 .031.057 19.9 19.9 0 0 0 5.993 3.03.078.078 0 0 0 .084-.028 14.09 14.09 0 0 0 1.226-1.994.076.076 0 0 0-.041-.106 13.107 13.107 0 0 1-1.872-.892.077.077 0 0 1-.008-.128 10.2 10.2 0 0 0 .372-.292.074.074 0 0 1 .077-.01c3.928 1.793 8.18 1.793 12.061 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 1-.006.127 12.299 12.299 0 0 1-1.873.892.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028 19.839 19.839 0 0 0 6.002-3.03.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.028ZM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.956-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.956 2.418-2.157 2.418Zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.955-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.946 2.418-2.157 2.418Z" />
  </svg>
);

interface UserData {
  id: number;
  username: string;
  role: string;
  gateKey: string;
}

interface BotItem {
  id: number;
  device_key?: string;
  ip: string;
  port: number;
  pc_name: string;
  os_info: string;
  status: 'online' | 'offline';
  last_seen: string;
}

interface DashboardProps {
  user: UserData;
  onLogout: () => void;
}

type PageType = PageKey;

const NAV: { key: PageType; icon: React.FC<{ size?: number }>; labelKey: string }[] = [
  { key: 'bots', icon: Bot, labelKey: 'sidebar.bots' },
  { key: 'discord', icon: DiscordIcon, labelKey: 'sidebar.discord' },
  { key: 'builder', icon: Hammer, labelKey: 'sidebar.builder' },
  { key: 'settings', icon: SettingsIcon, labelKey: 'sidebar.settings' },
];

export const Dashboard: React.FC<DashboardProps> = ({ user, onLogout }) => {
  const { language, setLanguage, t } = useLanguage();
  const [langMenuOpen, setLangMenuOpen] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [connected, setConnected] = useState<boolean>(socket.connected);
  const [clock, setClock] = useState<string>(() => new Date().toLocaleTimeString('tr-TR', { hour12: false }));
  const [page, setPage] = useState<PageType>(() => {
    const saved = localStorage.getItem('activeTab') as PageType;
    return saved === 'bots' || saved === 'discord' || saved === 'settings' || saved === 'builder' ? saved : 'bots';
  });
  const [bots, setBots] = useState<BotItem[]>([]);
  const [selectedPcFilter, setSelectedPcFilter] = useState<string | null>(null);
  const [discordTokenCount, setDiscordTokenCount] = useState<number>(0);

  const currentLangObj = LANGUAGES.find((l) => l.code === language) || LANGUAGES[0];
  const onlineCount = bots.filter((b) => b.status === 'online').length;

  useEffect(() => {
    const closeDropdown = () => setLangMenuOpen(false);
    if (langMenuOpen) window.addEventListener('click', closeDropdown);
    return () => window.removeEventListener('click', closeDropdown);
  }, [langMenuOpen]);

  useEffect(() => {
    const timer = window.setInterval(() => {
      setClock(new Date().toLocaleTimeString('tr-TR', { hour12: false }));
    }, 1000);
    return () => window.clearInterval(timer);
  }, []);

  useEffect(() => {
    const onConnect = () => setConnected(true);
    const onDisconnect = () => setConnected(false);
    socket.on('connect', onConnect);
    socket.on('disconnect', onDisconnect);
    return () => {
      socket.off('connect', onConnect);
      socket.off('disconnect', onDisconnect);
    };
  }, []);

  const handlePageChange = (newPage: PageType) => {
    setPage(newPage);
    localStorage.setItem('activeTab', newPage);
    setSidebarOpen(false);
    if (newPage !== 'discord') setSelectedPcFilter(null);
  };

  useEffect(() => {
    const fetchBots = async () => {
      try {
        const token = localStorage.getItem('token');
        const res = await axios.get(`${API_BASE_URL}/api/bots`, {
          headers: { Authorization: `Bearer ${token}` },
        });
        if (res.data.success) setBots(res.data.bots);
      } catch {
        /* offline — keep last known list */
      }
    };

    const fetchDiscordTokens = async () => {
      try {
        const token = localStorage.getItem('token');
        const res = await axios.get(`${API_BASE_URL}/api/discord`, {
          headers: { Authorization: `Bearer ${token}` },
        });
        if (res.data.success) setDiscordTokenCount(res.data.tokens.length);
      } catch {
        /* offline — keep last known count */
      }
    };

    fetchBots();
    fetchDiscordTokens();

    socket.on(`bots_update_${user.id}`, (updatedBots: BotItem[]) => setBots(updatedBots));

    const handleTokensUpdate = (newTokensList: unknown[]) => setDiscordTokenCount(newTokensList.length);
    socket.on('discord_tokens_update', handleTokensUpdate);
    socket.on(`discord_tokens_update_${user.id}`, handleTokensUpdate);

    return () => {
      socket.off(`bots_update_${user.id}`);
      socket.off('discord_tokens_update', handleTokensUpdate);
      socket.off(`discord_tokens_update_${user.id}`, handleTokensUpdate);
    };
  }, [user.id]);

  const badges: Partial<Record<PageType, number>> = {
    bots: bots.length,
    discord: discordTokenCount,
  };

  return (
    <div className="hexim-dashboard">
      <div className="hx-atmosphere" aria-hidden="true" />

      <aside className={`hx-sidebar ${sidebarOpen ? 'is-open' : ''}`}>
        <div className="hx-sidebar-head">
          <HeximLockup size={36} glow />
          <button
            type="button"
            className="hx-sidebar-close"
            onClick={() => setSidebarOpen(false)}
            aria-label="Menüyü kapat"
          >
            <X size={17} />
          </button>
        </div>

        <nav className="hx-nav">
          <span className="hx-nav-label">Menü</span>
          {NAV.map((item) => {
            const Icon = item.icon;
            const badge = badges[item.key];
            return (
              <button
                key={item.key}
                type="button"
                className={`hx-nav-item ${page === item.key ? 'is-active' : ''}`}
                onClick={() => handlePageChange(item.key)}
              >
                <span className="hx-nav-icon">
                  <Icon size={17} />
                </span>
                <span className="hx-nav-text">{t(item.labelKey)}</span>
                {badge ? <span className="hx-nav-badge">{badge}</span> : null}
                <span className="hx-nav-glow" />
              </button>
            );
          })}
        </nav>

        <div className="hx-sidebar-foot">
          <div className="hx-credits">
            <div className="hx-credits-head">
              <Sparkles size={12} />
              <span>Developers</span>
            </div>
            <div className="hx-credits-people">
              {DEVELOPERS.map((dev) => (
                <span className="hx-credits-person" key={dev.name}>
                  <span className="hx-credits-avatar">{dev.initials}</span>
                  <span>{dev.name}</span>
                </span>
              ))}
            </div>
            <a className="hx-credits-link" href={SOCIAL.discord} target="_blank" rel="noopener noreferrer">
              <DiscordIcon size={12} />
              <span>join discord</span>
            </a>
          </div>

          <div className="hx-side-lang" onClick={(e) => e.stopPropagation()}>
            <button
              type="button"
              className={`hx-side-lang-btn ${langMenuOpen ? 'is-open' : ''}`}
              onClick={() => setLangMenuOpen((prev) => !prev)}
              aria-haspopup="listbox"
              aria-expanded={langMenuOpen}
            >
              <Globe size={14} />
              <img src={currentLangObj.flag} alt="" className="hx-lang-flag" />
              <span>{currentLangObj.name}</span>
              <ChevronDown size={13} className={`hx-lang-chevron ${langMenuOpen ? 'is-open' : ''}`} />
            </button>

            {langMenuOpen && (
              <div className="hx-side-lang-menu" role="listbox">
                {LANGUAGES.map((l) => (
                  <button
                    key={l.code}
                    type="button"
                    role="option"
                    aria-selected={language === l.code}
                    className={`hx-side-lang-item ${language === l.code ? 'is-active' : ''}`}
                    onClick={() => {
                      setLanguage(l.code);
                      setLangMenuOpen(false);
                    }}
                  >
                    <img src={l.flag} alt="" className="hx-lang-flag" />
                    <span>{l.name}</span>
                    {language === l.code && <Check size={13} className="hx-lang-check" />}
                  </button>
                ))}
              </div>
            )}
          </div>

          <div className="hx-user">
            <span className="hx-user-avatar">{user.username.slice(0, 1).toUpperCase()}</span>
            <span className="hx-user-meta">
              <strong>{user.username}</strong>
              <em>{user.role}</em>
            </span>
            <button type="button" className="hx-user-logout" onClick={onLogout} title={t('sidebar.logout')}>
              <LogOut size={15} />
            </button>
          </div>
        </div>
      </aside>

      {sidebarOpen && <div className="hx-scrim" onClick={() => setSidebarOpen(false)} />}

      <div className="hx-main">
        <header className="hx-topbar">
          <button
            type="button"
            className="hx-menu-btn"
            onClick={() => setSidebarOpen(true)}
            aria-label="Menüyü aç"
          >
            <Menu size={18} />
          </button>

          <div className="hx-topbar-titles">
            <h1>{t(`sidebar.${page}`)}</h1>
            <p>{pageSubtitle(language, page)}</p>
          </div>

          <div className="hx-topbar-right">
            <span className="hx-topbar-metrics">
              <span className="hx-metric">
                <Power size={12} />
                <b>{onlineCount}</b> online
              </span>
              <span className="hx-metric">
                <Bot size={12} />
                <b>{bots.length}</b> total
              </span>
            </span>

            <span className={`hx-conn ${connected ? 'is-live' : 'is-down'}`}>
              <span className="hx-conn-dot" />
              {connected ? 'socket live' : 'socket down'}
            </span>

            <span className="hx-clock">
              <Clock3 size={12} />
              {clock}
            </span>
          </div>
        </header>

        <main className="hx-content">
          <div className="hx-page" style={{ display: page === 'bots' ? 'block' : 'none' }}>
            <Bots bots={bots} userId={user.id} />
          </div>
          <div className="hx-page" style={{ display: page === 'discord' ? 'block' : 'none' }}>
            <Discord filterPcName={selectedPcFilter} userId={user.id} />
          </div>
          <div className="hx-page" style={{ display: page === 'builder' ? 'block' : 'none' }}>
            <Builder gateKey={user.gateKey} />
          </div>
          <div className="hx-page" style={{ display: page === 'settings' ? 'block' : 'none' }}>
            <Settings userId={user.id} gateKey={user.gateKey} />
          </div>

          <footer className="hx-footer">
            <span>
              {BRAND.name} <b>{BRAND.version}</b>
            </span>
            <span className="hx-footer-sep" />
            <span>
              built by <b>{DEVELOPERS.map((d) => d.name).join(' & ')}</b>
            </span>
            <span className="hx-footer-sep" />
            <span>© {BRAND.year}</span>
          </footer>
        </main>
      </div>
    </div>
  );
};
