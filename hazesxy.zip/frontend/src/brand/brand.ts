/**
 * Hexim Project — single source of truth for naming, credits and copy.
 * Change a value here and it propagates through login, sidebar, topbar and settings.
 */

export const BRAND = {
  name: 'Hexim Project',
  wordmark: 'HEXIM',
  wordmarkTail: 'PROJECT',
  version: 'v2.0.4',
  year: 2026,
  tagline: 'Next-generation remote administration & security research suite',
} as const;

export interface Developer {
  name: string;
  handle: string;
  role: string;
  initials: string;
  accent: string;
}

export const DEVELOPERS: Developer[] = [
  {
    name: 'hazerux',
    handle: '@hazeruxdev',
    role: 'Core · Interface',
    initials: 'HX',
    accent: '#c9a86a',
  },
  {
    name: 'nexim',
    handle: '@nexim.xml',
    role: 'Backend · Client',
    initials: 'NX',
    accent: '#d8c8a4',
  },
];

export const SOCIAL = {
  discord: 'https://discord.gg/hD99cGZWY5',
} as const;

/** Localised one-liner used on the login screen. */
const TAGLINES: Record<string, string> = {
  tr: 'Yeni nesil uzaktan yönetim ve güvenlik araştırması paketi.',
  en: 'Next-generation remote administration & security research suite',
  ru: 'Панель нового поколения для удалённого администрирования и исследований безопасности.',
  es: 'Suite de nueva generación para administración remota e investigación de seguridad.',
  ar: 'منصة الجيل الجديد للإدارة عن بُعد وأبحاث الأمان.',
  zh: '新一代远程管理与安全研究控制台。',
};

export const tagline = (lang: string): string => TAGLINES[lang] || BRAND.tagline;

export type PageKey = 'bots' | 'discord' | 'builder' | 'settings';

interface PageCopy {
  subtitle: string;
}

/**
 * Short topbar subtitle per page. Turkish + English are hand written,
 * every other locale falls back to English so the chrome never shows a key.
 */
export const PAGE_COPY: Record<'tr' | 'en' | 'ru' | 'es' | 'ar' | 'zh', Record<PageKey, PageCopy>> = {
  tr: {
    bots: { subtitle: 'Bağlı cihazları izleyin, komut gönderin ve oturumları yönetin.' },
    discord: { subtitle: 'Yakalanan Discord oturumlarını görüntüleyin ve dışa aktarın.' },
    builder: { subtitle: 'Sunucunuza bağlanan istemciyi anında derleyin.' },
    settings: { subtitle: 'Gate key, gizlilik modu ve hesap güvenliği.' },
  },
  en: {
    bots: { subtitle: 'Monitor connected devices, dispatch commands and manage sessions.' },
    discord: { subtitle: 'Inspect and export captured Discord sessions.' },
    builder: { subtitle: 'Compile a client bound to your server in seconds.' },
    settings: { subtitle: 'Gate key, privacy mode and account security.' },
  },
  ru: {
    bots: { subtitle: 'Мониторинг устройств, отправка команд и управление сессиями.' },
    discord: { subtitle: 'Просмотр и экспорт перехваченных сессий Discord.' },
    builder: { subtitle: 'Сборка клиента, привязанного к вашему серверу.' },
    settings: { subtitle: 'Ключ доступа, режим приватности и безопасность аккаунта.' },
  },
  es: {
    bots: { subtitle: 'Supervisa dispositivos, envía comandos y gestiona sesiones.' },
    discord: { subtitle: 'Revisa y exporta las sesiones de Discord capturadas.' },
    builder: { subtitle: 'Compila un cliente vinculado a tu servidor en segundos.' },
    settings: { subtitle: 'Gate key, modo privacidad y seguridad de la cuenta.' },
  },
  ar: {
    bots: { subtitle: 'راقب الأجهزة المتصلة وأرسل الأوامر وأدر الجلسات.' },
    discord: { subtitle: 'استعرض جلسات ديسكورد التي تم التقاطها وصدّرها.' },
    builder: { subtitle: 'ابنِ عميلاً مرتبطاً بخادمك في ثوانٍ.' },
    settings: { subtitle: 'مفتاح الدخول ووضع الخصوصية وأمان الحساب.' },
  },
  zh: {
    bots: { subtitle: '监控在线设备、下发指令并管理会话。' },
    discord: { subtitle: '查看并导出捕获的 Discord 会话。' },
    builder: { subtitle: '几秒内编译绑定到服务器的客户端。' },
    settings: { subtitle: 'Gate Key、隐私模式与账户安全。' },
  },
};

export const pageSubtitle = (lang: string, page: PageKey): string => {
  const table = PAGE_COPY[lang as keyof typeof PAGE_COPY] || PAGE_COPY.en;
  return (table || PAGE_COPY.en)[page].subtitle;
};
