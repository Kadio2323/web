/**
 * Runtime configuration.
 *
 * Every value resolves from the build environment with a safe default, so the
 * same bundle runs on a laptop and on a VDS without a code change.
 *
 *   VITE_API_URL    absolute API origin; empty means "same origin" (recommended)
 *   VITE_CLIENT_HOST explicit host:port written into the generated client
 *   VITE_CLIENT_PORT backend port used for the generated client (default 3434)
 */

const env = import.meta.env;

const trimmed = (value: unknown): string =>
  typeof value === 'string' ? value.trim() : '';

export const API_BASE_URL = trimmed(env.VITE_API_URL);

export const CLIENT_HOST = trimmed(env.VITE_CLIENT_HOST);

export const CLIENT_PORT = trimmed(env.VITE_CLIENT_PORT) || '3434';
