import { useState, useEffect } from 'react';
import axios from 'axios';
import './styles/global.css';
import './styles/hexim-ui.css';
import { Login } from './components/Login/Login';
import { Dashboard } from './components/Dashboard/Dashboard';
import { HeximMark } from './components/Brand/HeximLogo';
import { LanguageProvider } from './i18n/LanguageContext';
import { PrivacyProvider } from './context/PrivacyContext';
import { API_BASE_URL } from './config';

interface UserData {
  id: number;
  username: string;
  role: string;
  gateKey: string;
}

export default function App() {
  const [user, setUser] = useState<UserData | null>(null);
  const [loading, setLoading] = useState<boolean>(true);

  useEffect(() => {
    const restoreSession = async () => {
      const token = localStorage.getItem('token');
      if (!token) {
        setLoading(false);
        return;
      }

      try {
        const res = await axios.get(`${API_BASE_URL}/api/auth/me`, {
          headers: { Authorization: `Bearer ${token}` },
        });

        if (res.data.success && res.data.user) {
          setUser({
            id: res.data.user.id,
            username: res.data.user.username,
            role: res.data.user.role,
            gateKey: res.data.user.gate_key || res.data.user.gateKey,
          });
        } else {
          localStorage.removeItem('token');
        }
      } catch {
        localStorage.removeItem('token');
      } finally {
        setLoading(false);
      }
    };

    restoreSession();
  }, []);

  const handleLoginSuccess = (userData: UserData, token: string) => {
    localStorage.setItem('token', token);
    setUser(userData);
  };

  const handleLogout = () => {
    localStorage.removeItem('token');
    setUser(null);
  };

  if (loading && !user) {
    return (
      <div className="hexim-app">
        <div className="hx-atmosphere">
          <div className="hx-blob b1" />
          <div className="hx-blob b2" />
          <div className="hx-grid-lines" />
        </div>
        <div className="hx-boot">
          <div className="hx-boot-mark">
            <HeximMark size={64} glow />
          </div>
          <div className="hx-boot-bar">
            <span />
          </div>
          <p className="hx-boot-text">HEXIM PROJECT · establishing session</p>
        </div>
      </div>
    );
  }

  const previewMode = new URLSearchParams(window.location.search).get('preview');
  if (previewMode) {
    return (
      <div className="hexim-app">
        <LanguageProvider>
          <PrivacyProvider>
            <Dashboard
              user={{ id: 1, username: 'hazerux', role: 'admin', gateKey: 'HX-9F2A-77C1-DEMO' }}
              onLogout={() => {}}
            />
          </PrivacyProvider>
        </LanguageProvider>
      </div>
    );
  }

  return (
    <div className="hexim-app">
      <LanguageProvider>
        <PrivacyProvider>
          {!user ? (
            <div className="app-wrapper">
              <Login onLoginSuccess={handleLoginSuccess} />
            </div>
          ) : (
            <Dashboard user={user} onLogout={handleLogout} />
          )}
        </PrivacyProvider>
      </LanguageProvider>
    </div>
  );
}
