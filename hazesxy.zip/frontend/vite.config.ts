import { defineConfig, loadEnv } from 'vite'
import react from '@vitejs/plugin-react'

// Backend origin is resolved from the environment so the same config works on a
// dev box, a VDS and inside docker. VITE_PROXY_TARGET wins, then BACKEND_URL,
// then the local default.
export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, process.cwd(), '')
  const target =
    env.VITE_PROXY_TARGET?.trim() ||
    env.BACKEND_URL?.trim() ||
    'http://localhost:5000'

  return {
    plugins: [react()],
    server: {
      host: env.HOST?.trim() || 'localhost',
      port: Number(env.PORT) || 5173,
      proxy: {
        '/api': {
          target,
          changeOrigin: true,
        },
        '/socket.io': {
          target,
          ws: true,
          changeOrigin: true,
        },
      },
    },
  }
})
