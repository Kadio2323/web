#!/bin/bash

# =========================================================
#  HEXIM PROJECT / BOT CONTROL PANEL - HIGH-SPEED INSTALLER
#  Debian 12 (Bookworm) & Ubuntu Full Stack Setup
# =========================================================

set -e
export DEBIAN_FRONTEND=noninteractive

clear
echo "========================================================="
echo "                  HEXIM PROJECT SETUP                    "
echo "========================================================="

# Root kontrolü
if [ "$EUID" -ne 0 ]; then
  echo "[ERROR] Bu betiği sudo veya root kullanıcısı olarak çalıştırmalısınız!"
  exit 1
fi

# Distro tespiti
if [ -f /etc/os-release ]; then
    . /etc/os-release
    DISTRO_ID="${ID}"
    DISTRO_CODENAME="${VERSION_CODENAME}"
else
    DISTRO_ID="debian"
    DISTRO_CODENAME="bookworm"
fi

# 🚀 ULTRA HIZLANDIRMA: APT Ayna Değişimi & Konfigürasyon Ayarları
echo "[1/6] İndirme hızlandırma ayarları uygulanıyor..."

# APT Paralel indirme ve önbellek kapatma optimizasyonu
cat <<'EOF' > /etc/apt/apt.conf.d/99fast-download
Acquire::http::Pipeline-Depth "20";
Acquire::http::No-Cache "true";
Acquire::Queue-Mode "host";
APT::Install-Recommends "0";
APT::Install-Suggests "0";
EOF

# Debian aynalarını en hızlı HTTPS/Global aynalara yönlendir
if [ "$DISTRO_ID" = "debian" ]; then
    cat <<EOF > /etc/apt/sources.list
deb http://deb.debian.org/debian ${DISTRO_CODENAME} main contrib non-free non-free-firmware
deb http://deb.debian.org/debian-security ${DISTRO_CODENAME}-security main contrib non-free non-free-firmware
deb http://deb.debian.org/debian ${DISTRO_CODENAME}-updates main contrib non-free non-free-firmware
EOF
fi

# 1. Paket yükleme (Yalnızca elzem paketler)
echo "[2/6] Bağımlılıklar hızlı modda yükleniyor..."
apt-get update -qq
apt-get install -y -qq --no-install-recommends \
  curl wget git ca-certificates gnupg lsb-release iptables ufw jq openjdk-17-jdk-headless

# 2. Docker CE ve Docker Compose Plugin hızlı kurulumu
echo "[3/6] Docker hızlı modda hazırlanıyor..."
install -m 0755 -d /etc/apt/keyrings
rm -f /etc/apt/keyrings/docker.gpg /etc/apt/sources.list.d/docker.list

curl -fsSL "https://download.docker.com/linux/${DISTRO_ID}/gpg" | gpg --dearmor -o /etc/apt/keyrings/docker.gpg
chmod a+r /etc/apt/keyrings/docker.gpg

echo \
  "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/${DISTRO_ID} \
  ${DISTRO_CODENAME} stable" | tee /etc/apt/sources.list.d/docker.list > /dev/null

apt-get update -qq
apt-get install -y -qq --no-install-recommends docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin

if ! command -v docker-compose &> /dev/null; then
    echo '#!/bin/sh' > /usr/local/bin/docker-compose
    echo 'exec docker compose "$@"' >> /usr/local/bin/docker-compose
    chmod +x /usr/local/bin/docker-compose
fi

# 3. Docker servisini başlat
systemctl daemon-reload
systemctl restart docker
systemctl enable docker

# 4. Proje dizini hazırlığı
echo "[4/6] Proje dosyaları senkronize ediliyor..."

# Kurulum dizini: APP_DIR ile değiştirilebilir, varsayılan /var/www/bot
APP_DIR="${APP_DIR:-/var/www/bot}"
mkdir -p "$APP_DIR"

SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
if [ "$SCRIPT_DIR" != "$APP_DIR" ]; then
    cp -rn "$SCRIPT_DIR"/* "$APP_DIR"/ 2>/dev/null || true
    cp -rn "$SCRIPT_DIR"/.* "$APP_DIR"/ 2>/dev/null || true
fi
cd "$APP_DIR"

mkdir -p "$APP_DIR/backend/uploads"
mkdir -p "$APP_DIR/backend/data"
mkdir -p "$APP_DIR/backend/client"

if [ -d "$APP_DIR/client" ]; then
    cp -rf "$APP_DIR/client"/* "$APP_DIR/backend/client"/ 2>/dev/null || true
fi

chmod -R 777 "$APP_DIR/backend/uploads" 2>/dev/null || true
chmod -R 777 "$APP_DIR/backend/data" 2>/dev/null || true
chmod -R 777 "$APP_DIR/backend/client" 2>/dev/null || true

rm -rf node_modules frontend/node_modules backend/node_modules dist frontend/dist backend/dist

# 5. Docker Konteynerleri Başlat
echo "[5/6] Docker Konteynerleri Başlatılıyor..."
docker compose down 2>/dev/null || true
docker compose build
docker compose up -d

echo "[INFO] Servislerin hazır olması bekleniyor (5sn)..."
sleep 5

# 6. Güvenlik Duvarı Port İzinleri
echo "[6/6] Port izinleri veriliyor..."
if command -v ufw &> /dev/null; then
    ufw allow 80/tcp 2>/dev/null || true
    ufw allow 3434/tcp 2>/dev/null || true
    ufw allow 5000/tcp 2>/dev/null || true
    ufw allow 22/tcp 2>/dev/null || true
fi

SERVER_IP=$(curl -s --max-time 5 https://api.ipify.org || curl -s --max-time 5 https://ifconfig.me || hostname -I | awk '{print $1}')

echo ""
echo "========================================================="
echo "       🎉 KURULUM BAŞARIYLA TAMAMLANDI! 🎉               "
echo "========================================================="
echo "📌 Web Paneli:         http://${SERVER_IP}"
echo "📌 Bot API Portu:      http://${SERVER_IP}:3434"
echo "📌 Varsayılan Kullanıcı: admin"
echo "📌 Varsayılan Şifre:    admin123"
echo "========================================================="
