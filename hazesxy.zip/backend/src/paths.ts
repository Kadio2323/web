/**
 * Runtime path resolution.
 *
 * Nothing here is machine-specific. Every directory is either supplied by the
 * environment, detected on the host at boot, or derived from the process
 * working directory — so the same build runs from a Windows dev box, a Linux
 * VDS, or a container without editing a single line.
 *
 *   DATA_DIR    persisted panel data (screenshots, sysinfo, downloaded files)
 *   TMP_DIR     scratch space for compilation and multipart uploads
 *   CLIENT_DIR  Java client sources used by the builder
 */

import * as fs from 'fs';
import * as os from 'os';
import * as path from 'path';

const fromEnv = (key: string): string | null => {
  const value = process.env[key];
  if (!value || !value.trim()) return null;
  return path.resolve(value.trim());
};

const isDir = (target: string): boolean => {
  try {
    return fs.statSync(target).isDirectory();
  } catch {
    return false;
  }
};

const writable = (target: string): boolean => {
  try {
    fs.mkdirSync(target, { recursive: true });
    fs.accessSync(target, fs.constants.W_OK);
    return true;
  } catch {
    return false;
  }
};

/* ------------------------------------------------------------------ data */

const resolveDataDir = (): string => {
  const explicit = fromEnv('DATA_DIR');
  if (explicit) return explicit;

  // container / VDS convention: a mounted volume at /data
  if (process.platform !== 'win32' && isDir('/data') && writable('/data')) {
    return '/data';
  }

  const local = path.join(process.cwd(), 'data');
  if (writable(local)) return local;

  const fallback = path.join(os.tmpdir(), 'hexim-data');
  fs.mkdirSync(fallback, { recursive: true });
  return fallback;
};

export const DATA_DIR = resolveDataDir();
export const BOTS_DIR = path.join(DATA_DIR, 'bots');

/* ------------------------------------------------------------- temp/upload */

export const TMP_DIR = fromEnv('TMP_DIR') || os.tmpdir();
export const UPLOAD_DIR = fromEnv('UPLOAD_DIR') || path.join(TMP_DIR, 'hexim-uploads');

/* ----------------------------------------------------------------- client */

const CLIENT_MARKER = 'Client.java';

const clientCandidates = (): string[] => {
  const entry = fromEnv('CLIENT_DIR');
  const roots = new Set<string>();

  if (entry) roots.add(entry);

  const starts = [process.cwd(), __dirname];
  for (const start of starts) {
    let current = start;
    for (let depth = 0; depth < 5; depth += 1) {
      roots.add(path.join(current, 'client'));
      roots.add(path.join(current, 'backend', 'client'));
      roots.add(path.join(current, '..', 'client'));
      const parent = path.dirname(current);
      if (parent === current) break;
      current = parent;
    }
  }

  return Array.from(roots).map((p) => path.resolve(p));
};

const resolveClientDir = (): string | null => {
  for (const candidate of clientCandidates()) {
    if (fs.existsSync(path.join(candidate, CLIENT_MARKER))) return candidate;
  }
  return null;
};

/** Null when no client source tree was shipped alongside the backend. */
export const CLIENT_DIR = resolveClientDir();

/* ---------------------------------------------------------------- helpers */

export const ensureDir = (target: string): string => {
  fs.mkdirSync(target, { recursive: true });
  return target;
};

export const botDir = (botId: number | string): string =>
  ensureDir(path.join(BOTS_DIR, String(botId)));

export const botScreenshotDir = (botId: number | string): string =>
  ensureDir(path.join(BOTS_DIR, String(botId), 'screenshots'));

export const botFilesDir = (botId: number | string): string =>
  ensureDir(path.join(BOTS_DIR, String(botId), 'files'));

export const botSysinfoPath = (botId: number | string): string =>
  path.join(botDir(botId), 'sysinfo.json');

export const buildScratchDir = (buildId: string): string =>
  ensureDir(path.join(TMP_DIR, buildId));

/** One boot-time line so a deploy log shows which roots were picked up. */
export const describePaths = (): string =>
  [
    `data=${DATA_DIR}`,
    `tmp=${TMP_DIR}`,
    `uploads=${UPLOAD_DIR}`,
    `client=${CLIENT_DIR || 'not found'}`,
  ].join(' ');

export const initPaths = (): void => {
  ensureDir(BOTS_DIR);
  ensureDir(UPLOAD_DIR);
  console.log(`[paths] ${describePaths()}`);
};
